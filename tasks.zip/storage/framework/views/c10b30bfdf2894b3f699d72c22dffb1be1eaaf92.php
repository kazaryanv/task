
<?php $__env->startSection('title'); ?>Sign up
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <h2>Sign up</h2>
                <form action="<?php echo e(route("register")); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">User name</label>
                        <input name="name" type="text" class="form-control" id="name" placeholder="John Smith">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">User email</label>
                        <input name="email" type="email" class="form-control" id="email" placeholder="example@gmail.com">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">User password</label>
                        <input name="password" type="password" class="form-control" id="password" placeholder="1234">
                    </div>

                    <button class="btn btn-primary">Register</button>
                </form>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasksnewLaravel\tasks\resources\views/Auth/register.blade.php ENDPATH**/ ?>