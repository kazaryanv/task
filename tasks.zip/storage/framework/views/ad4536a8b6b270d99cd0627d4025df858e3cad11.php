
<?php $__env->startSection('title'); ?>
    image
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('new-image')); ?>">Create new post</a>
        <?php if(isset($data)): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex">
                    <div>
                    <h2><?php echo e($row -> name); ?></h2>
                    <p><?php echo e($row -> content); ?></p>
                    </div>
                    <div style="width: 15%;height: 70px;display: flex;align-items: center;justify-content: center;">
                        <img style="width: 50px;height: 50px;" src="<?php echo e(asset('storage/' . $row -> image)); ?>">
                    </div>
                </div>
                    <a href="<?php echo e(route('one-image', $row)); ?>">More</a>
                <div style="border-bottom-style: ridge;"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasksnewLaravel\tasks\resources\views/image_admin.blade.php ENDPATH**/ ?>