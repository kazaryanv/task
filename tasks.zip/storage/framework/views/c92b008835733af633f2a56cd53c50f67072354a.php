
<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('title')); ?>">Back</a>
                    <h2>Slug`<?php echo e($title->slug); ?></h2>
                    <p>Title`<?php echo e($title -> title); ?></p>
                    <p>Description`<?php echo e($title -> description); ?></p>
                    <button class="btn btn-primary">
                        <a style="color:white; text-decoration: none" href="<?php echo e(route('edit-title', $title->id)); ?>">Edit</a>
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasksnewLaravel\tasks\resources\views/home-page.blade.php ENDPATH**/ ?>