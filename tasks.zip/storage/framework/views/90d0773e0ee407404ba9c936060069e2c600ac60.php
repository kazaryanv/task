
<?php $__env->startSection('title'); ?>
    image
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('store-image')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label style="display: flex; justify-content: center" for="image" class="form-label">File and Image</label>
            <input style="height: unset" class="form-control" type="file" id="image" name="image" multiple />
        </div>
        <div class="form-outline mb-4">
            <label style="display: flex; justify-content: center" class="form-label" for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control" />
        </div>
        <div class="form-outline mb-4">
            <label style="display: flex; justify-content: center" class="form-label" for="content">contents</label>
            <textarea class="form-control" id="content" name="content" rows="4"></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-block">
            Send
        </button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasksnewLaravel\tasks\resources\views/new_image.blade.php ENDPATH**/ ?>